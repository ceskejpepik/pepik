﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace seriova_komunikace
{
    public partial class Form1 : Form
    {
        public TextBox[] displej = new TextBox[8];
        SerialPort port;
        string adresa_portu = "COM3";
        int baud = 9600;
        public Form1()
        {
            
            InitializeComponent();
            //načtení textboxů do pole
             displej[0] = textBox2;
             displej[1] = textBox3;
             displej[2] = textBox4;
             displej[3] = textBox5;
             displej[4] = textBox6;
             displej[5] = textBox7;
             displej[6] = textBox8;
             displej[7] = textBox9;
             if (port == null)
             {
               //vybrání výstupního portu a baudové rychlosti
               port = new SerialPort(adresa_portu, baud); 
               //otevření portu
               port.Open();
             }
        }
        int cteni()
        { 
            int cislo;
            string nacteny_znak;
            //načtení řetězce z textboxu pro zadávání čísla do proměnné
            nacteny_znak = textBox1.Text;
            //pokud je načtený řetězec číslo pak tento řetězec převede na celé číslo 
            if (int.TryParse(nacteny_znak,out cislo))
            //vrátí toto číslo a ukončí funkci
            { return cislo; }
            //pokud zadaný řetězec není číslo pak vrátí -1 a ukončí funkci
            else return -1;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //pokud se jedná o celé číslo 0 až 9
            if ((cteni() <= 9) && (cteni() >= 0))
            {
                //posun čísel v textboxech pro zobratování stavu displeje
                for (int i = 7; i > 0; i--)
                {
                    displej[i].Text = displej[i-1].Text;
                
                }
                //odesláni hodnoty na výstup
                port.Write(cteni().ToString());
                //zapsání do listboxu co bylo právě provedeno
                listBox1.Items.Add("Bylo odesláno číslo " + cteni().ToString());
                //zapsní čísla do prvního textboxu
                textBox2.Text = Convert.ToString(cteni()); 
            }
            //jinak se jedná o neočekávaný znak
            else
            {
                //zapsání do listboxu co bylo právě provedeno
                listBox1.Items.Add("Byl zadán neočekávaný znak, zadejte prosím celé číslo 0 až 9");
            }
            //vymazání textboxu pro zadávání čísla
            textBox1.Clear();
            textBox1.Focus();

        }

    }
}
